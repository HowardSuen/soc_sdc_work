"""
# @ Author:      Zhenyu Yan(Kevin)
# @ Create Time: 2025-03-25
# @ Description: COPYRIGHT(C) 2022-2025. ALL RIGHTS RESERVED.
# @ Note:        Proprietary and Confidential Information. Not to be copied or distributed.
"""

import pandas as pd
import glob
import argparse


def compare_widths(signals, signal_type, file_path, module_name):
    for signal, width, used_width, _ in signals:
        if used_width != "":
            if width != used_width:
                print(f"File: {file_path}, module name: {module_name}")
                print(f"Warning: {signal_type} Width mismatch for signal '{signal}': {int(width)} vs {int(used_width)}")


def generate_top_v(check_width=False):
    port_files = glob.glob("port_*.xlsx")
    with open("top.v", "w") as f:
        f.write("module top (\n")
        signals_all = {"Inout": [], "Input": [], "Output": []}
        for file_path in port_files:
            sheet_names = pd.ExcelFile(file_path).sheet_names
            for sheet_name in sheet_names:
                signals = {"Inout": [], "Input": [], "Output": []}
                sheet_df = pd.read_excel(file_path, sheet_name=sheet_name)
                for io, io_width, io_connectivity, io_name in zip(sheet_df["Inout"].fillna("").tolist(), sheet_df["Inout Width"].fillna("").tolist(), sheet_df["Inout Connectivity"].fillna("").tolist(), sheet_df["Inout Name"].fillna("").tolist()):
                    if io != "":
                        signals["Inout"].append([io, io_width, io_connectivity, io_name])
                        signals_all["Inout"].append([io, io_width, io_connectivity, io_name])
                for inp, inp_width, inp_used_width, from_whom in zip(sheet_df["Input"].fillna("").tolist(), sheet_df["Input Width"].fillna("").tolist(), sheet_df["Input Used Width"].fillna("").tolist(), sheet_df["From Whom"].fillna("").tolist()):
                    if inp != "":
                        signals["Input"].append([inp, inp_width, inp_used_width, from_whom])
                        signals_all["Input"].append([inp, inp_width, inp_used_width, from_whom])
                for out, out_width, out_used_width, to_top in zip(sheet_df["Output"].fillna("").tolist(), sheet_df["Output Width"].fillna("").tolist(), sheet_df["Output Used Width"].fillna("").tolist(), sheet_df["To Top"].fillna("").tolist()):
                    if out != "":
                        signals["Output"].append([out, out_width, out_used_width, to_top])
                        signals_all["Output"].append([out, out_width, out_used_width, to_top])

                if check_width:
                    compare_widths(signals["Input"], "Input", file_path, sheet_name)
                    compare_widths(signals["Output"], "Output", file_path, sheet_name)

        def calculate_spaces(signals):
            spaces = []
            for signal, width, _, _ in signals:
                widths = []
                widths.append(width)
                width = widths[0] if widths else ""
                width_str = f"[{int(width) - 1}:0] " if width and int(width) - 1 != 0 else ""
                spaces.append(" " * (len(width_str) + 1))
            return spaces

        spaces_input = calculate_spaces(signals_all["Input"])
        spaces_output = calculate_spaces(signals_all["Output"])
        spaces_inout = calculate_spaces(signals_all["Inout"])

        max_spaces_length = max(max((len(s) for s in spaces_input), default=0), max((len(s) for s in spaces_output), default=0), max((len(s) for s in spaces_inout), default=0))
        spaces = " " * max_spaces_length

        signals_inout_top = []
        for inout, inout_width, connectivity, name in signals_all["Inout"]:
            width = inout_width
            width_str = " " * (len(spaces) - len(f"[{int(width) - 1}:0] ")) + f"[{int(width) - 1}:0] " if width and int(width) - 1 != 0 else ""
            if connectivity.startswith("top."):
                connectivity = connectivity[4:]
            else:
                connectivity = connectivity.split(".")[1]
            # Collect (connectivity, width_str, width) for later filtering
            signals_inout_top.append((connectivity, width_str, int(inout_width) if inout_width else 0))
        filtered_signals = {}
        for conn, width_str, width in signals_inout_top:
            if conn not in filtered_signals or width > filtered_signals[conn][1]:
                filtered_signals[conn] = (width_str, width)
        signals_inout_top = [(conn, filtered_signals[conn][0]) for conn in filtered_signals]
        for signal, width_str in signals_inout_top:
            spaces_end = " " * (max(len(signal), 50) - len(signal))
            if width_str == "":
                f.write(f"    inout  wire {spaces}{signal}{spaces_end},\n")
            else:
                f.write(f"    inout  wire {width_str}{signal}{spaces_end},\n")

        signals_input_top = []
        for input_signal, width, used_width, from_whom in signals_all["Input"]:
            width_str = " " * (len(spaces) - len(f"[{int(width) - 1}:0] ")) + f"[{int(width) - 1}:0] " if width and int(width) - 1 != 0 else ""
            if from_whom.startswith("top."):
                from_whom = from_whom[4:]
                signals_input_top.append((from_whom, width_str))
            else:
                for input_s, _, _, _ in signals_all["Input"]:
                    if input_s == from_whom:
                        from_whom = input_s
                        signals_input_top.append((from_whom, width_str))
        signals_input_top = list(set(signals_input_top))
        for signal, width_str in signals_input_top:
            spaces_end = " " * (max(len(signal), 50) - len(signal))
            if width_str == "":
                f.write(f"    input  wire {spaces}{signal}{spaces_end},\n")
            else:
                f.write(f"    input  wire {width_str}{signal}{spaces_end},\n")

        signals_output_top = []
        for output_signal, width, used_width, to_top in signals_all["Output"]:
            width_str = " " * (len(spaces) - len(f"[{int(width) - 1}:0] ")) + f"[{int(width) - 1}:0] " if width and int(width) - 1 != 0 else ""
            if to_top=="Y":
                signals_output_top.append((output_signal, width_str))
        signals_output_top = list(set(signals_output_top))
        for signal, width_str in signals_output_top:
            spaces_end = " " * (max(len(signal), 50) - len(signal))
            if width_str == "":
                f.write(f"    output wire {spaces}{signal}{spaces_end},\n")
            else:
                f.write(f"    output wire {width_str}{signal}{spaces_end},\n")

        f.write(");\n\n")

        # wire
        unique_inout_data = {}
        unique_from_whom_data = {}
        unique_output_data = {}
        for inout, inout_width, connectivity, name in signals_all["Inout"]:
            if name not in unique_inout_data and name != "":
                unique_inout_data[name] = {"inout_width": inout_width}
        for input_signal, width, used_width, from_whom in signals_all["Input"]:
            if from_whom not in unique_from_whom_data and from_whom != "":
                unique_from_whom_data[from_whom] = {"from_whom_width": used_width}
        for file_path in port_files:
            sheet_names = pd.ExcelFile(file_path).sheet_names
            for sheet_name in sheet_names:
                sheet_df = pd.read_excel(file_path, sheet_name=sheet_name)
                if "Output" in sheet_df.columns:
                    for _, row in sheet_df.iterrows():
                        output = row.get("Output", "") if pd.notna(row.get("Output", "")) else ""
                        if output != "":
                            output = sheet_name + "_" + str(output)
                        output_width = row.get("Output Width", "") if pd.notna(row.get("Output Width", "")) else ""
                        to_top = row.get("To Top", "") if pd.notna(row.get("To Top", "")) else ""
                        if output != "":
                            if output not in unique_output_data and to_top != "Y":
                                unique_output_data[output] = {"output_width": output_width}

        for inout_name, data in unique_inout_data.items():
            spaces_inout = []
            inout_width = data["inout_width"]
            widths = [inout_width]
            widths = [int(w) for w in widths if w]
            if widths:  # Ensure widths is not empty
                max_width = max(widths)
                spaces_inout.append(" " * (len(f"[{max_width - 1}:0] ") + 1))
            else:
                max_width = 0  # Default value if no valid widths
        for from_whom, data in unique_from_whom_data.items():
            spaces_from_whom = []
            input_used_width = data["from_whom_width"]
            widths = [input_used_width]
            widths = [int(w) for w in widths if w]
            max_width = max(widths) if widths else 0
            width_str = f"[{max_width - 1}:0] " if max_width > 1 else ""
            spaces_from_whom.append(" " * (len(f"[{max_width - 1}:0] ") + 1))
        for output, data in unique_output_data.items():
            spaces_output = []
            output_width = data["output_width"]
            widths = [output_width]
            widths = [int(w) for w in widths if w]
            if widths:  # Ensure widths is not empty
                max_width = max(widths)
                spaces_output.append(" " * (len(f"[{max_width - 1}:0] ") + 1))
            else:
                max_width = 0  # Default value if no valid widths
        max_spaces_inout = max(spaces_inout, key=len) if spaces_inout else ""
        max_spaces_from_whom = max(spaces_from_whom, key=len) if spaces_from_whom else ""
        max_spaces_output = max(spaces_output, key=len) if spaces_output else ""
        max_spaces_length = max(len(max_spaces_inout), len(max_spaces_from_whom), len(max_spaces_output))
        spaces = " " * max_spaces_length

        for inout_name, data in unique_inout_data.items():
            inout_width = data["inout_width"]
            widths = [inout_width]
            widths = [int(w) for w in widths if w]
            max_width = max(widths) if widths else 0
            width_str = " " * (len(spaces) - len(f"[{max_width - 1}:0] ")) + f"[{max_width - 1}:0] " if max_width > 1 else ""
            if inout_name.startswith("top."):
                continue
            else:
                inout_name = inout_name.replace(".", "_")
            spaces_end = " " * (max(len(inout_name), 50) - len(inout_name))
            if width_str == "":
                f.write(f"wire {spaces}{inout_name}{spaces_end};\n")
            else:
                f.write(f"wire {width_str}{inout_name}{spaces_end};\n")
        for from_whom, data in unique_from_whom_data.items():
            input_used_width = data["from_whom_width"]
            widths = [input_used_width]
            widths = [int(w) for w in widths if w]
            max_width = max(widths) if widths else 0
            width_str = " " * (len(spaces) - len(f"[{max_width - 1}:0] ")) + f"[{max_width - 1}:0] " if max_width > 1 else ""
            if from_whom.startswith("top.") or "'" in from_whom or "[" in from_whom or "]" in from_whom or "{" in from_whom or "}" in from_whom:
                continue
            else:
                from_whom = from_whom.replace(".", "_")
            spaces_end = " " * (max(len(from_whom), 50) - len(from_whom))
            if width_str == "":
                f.write(f"wire {spaces}{from_whom}{spaces_end};\n")
            else:
                f.write(f"wire {width_str}{from_whom}{spaces_end};\n")
        for output, data in unique_output_data.items():
            output_width = data["output_width"]
            widths = [output_width]
            widths = [int(w) for w in widths if w]
            max_width = max(widths) if widths else 0
            width_str = " " * (len(spaces) - len(f"[{max_width - 1}:0] ")) + f"[{max_width - 1}:0] " if max_width > 1 else ""
            if output.startswith("top."):
                continue
            else:
                output = output.replace(".", "_")
            spaces_end = " " * (max(len(output), 50) - len(output))
            if width_str == "":
                f.write(f"wire {spaces}{output}{spaces_end};\n")
            else:
                f.write(f"wire {width_str}{output}{spaces_end};\n")

        f.write("\n")

        # submodule
        def process_submodule_connections(sheet_df, column_pairs, prefix="top."):
            for column, connection_column in column_pairs:
                if column in sheet_df.columns and connection_column in sheet_df.columns:
                    data = sheet_df[[column, connection_column]].dropna(how="all")
                    for idx, (_, row) in enumerate(data.iterrows()):
                        signal, connection = row[column], row[connection_column]
                        if pd.notna(connection):
                            if connection_column == "Inout Connectivity" and not connection.startswith(prefix):
                                inout_name_data = sheet_df["Inout Name"].dropna()
                                for ion in inout_name_data:
                                    inout_name = ion
                                if pd.isna(signal):
                                    continue
                                f.write(f"    .{signal}({inout_name}),\n")
                            elif connection_column == "Inout Connectivity" and connection.startswith(prefix):
                                if pd.isna(signal):
                                    continue
                                connection = connection[len(prefix) :]
                                f.write(f"    .{signal}({connection}),\n")
                            elif connection_column == "To Top":
                                if pd.isna(signal):
                                    continue
                                if connection == "Y":
                                    f.write(f"    .{signal}({signal}),\n")
                            elif connection_column == "From Whom":
                                if pd.isna(signal):
                                    continue
                                if connection.startswith(prefix):
                                    connection = connection[len(prefix) :]
                                else:
                                    connection = connection.replace(".", "_")
                                f.write(f"    .{signal}({connection}),\n")
                        else:
                            if pd.isna(signal):
                                continue
                            f.write(f"    .{signal}({sheet_name}_{signal}),\n")

        # Process submodules
        for file_path in port_files:
            print(f"{file_path} is processed.")
            for sheet_name in pd.ExcelFile(file_path).sheet_names:
                sheet_df = pd.read_excel(file_path, sheet_name=sheet_name)

                # Write submodule header
                parameter_data = [param for param in sheet_df["Parameter"].dropna().tolist() if param.startswith("parameter")] if "Parameter" in sheet_df.columns else []
                if not parameter_data:
                    f.write(f"{sheet_name[2:]} {sheet_name} (\n")
                else:
                    f.write(f"{sheet_name[2:]} #(\n")
                    for idx, param in enumerate(parameter_data):
                        if param.startswith("parameter"):
                            param_name, param_value = param.split(" ")[1].upper(), param.split("=")[1].strip()[:-1]
                            f.write(f"    .{param_name}({param_value}),\n")
                    f.write(f") {sheet_name} (\n")

                column_pairs = [("Inout", "Inout Connectivity"), ("Input", "From Whom"), ("Output", "To Top")]

                process_submodule_connections(sheet_df, column_pairs)

                f.write(");\n\n")

        f.write("endmodule\n")

    # Post processing......
    # Remove duplicate wire lines while preserving original positions
    unique_lines = {}
    updated_lines = []
    with open("top.v", "r") as f:
        lines = f.readlines()
    for line in lines:
        if line.strip().startswith("wire "):
            # Extract the signal name and width
            parts = line.strip().split()
            if len(parts) > 2 and parts[1].startswith("["):  # Line with width declaration
                signal_name = parts[2]
                width_declared = True
            else:  # Line without width declaration
                signal_name = parts[1]
                width_declared = False

            # Check if the signal is already in unique_lines
            if signal_name in unique_lines:
                # If the existing line does not have width and the current line does, replace it
                if width_declared and not unique_lines[signal_name][1]:
                    unique_lines[signal_name] = (line, width_declared)
            else:
                unique_lines[signal_name] = (line, width_declared)
                updated_lines.append(line)  # Keep the original position
        else:
            updated_lines.append(line)

    with open("top.v", "w") as f:
        for line in updated_lines:
            if line.strip().startswith("wire "):
                # Write the unique wire line
                signal_name = line.strip().split()[1 if "[" not in line else 2]
                f.write(unique_lines[signal_name][0])
            else:
                f.write(line)

    # Sort the ports in the module top by their names alphabetically
    with open("top.v", "r") as f:
        lines = f.readlines()

    module_start = None
    module_end = None

    for i, line in enumerate(lines):
        if line.strip().startswith("module top"):
            module_start = i
        if module_start is not None and line.strip() == ");":
            module_end = i
            break

    line_inout = []
    line_input = []
    line_output = []
    if module_start is not None and module_end is not None:
        # Extract and sort the port declarations
        port_lines = lines[module_start + 1 : module_end]
        for line in port_lines:
            if line.strip().startswith('inout '):
                line_inout.append(line)
            elif line.strip().startswith('input '):
                line_input.append(line)
            elif line.strip().startswith('output '):
                line_output.append(line)
        sorted_inout = sorted(line_inout, key=lambda x: x.strip().rstrip(",").split()[-1])
        sorted_input = sorted(line_input, key=lambda x: x.strip().rstrip(",").split()[-1])
        sorted_output = sorted(line_output, key=lambda x: x.strip().rstrip(",").split()[-1])
        lines = lines[: module_start + 1] + sorted_inout + sorted_input + sorted_output + lines[module_end:]
    with open("top.v", "w") as f:
        f.writelines(lines)

    # Remove trailing commas from the last port declaration
    with open("top.v", "r") as f:
        lines = f.readlines()
        for i in range(len(lines)):
            if lines[i].strip().startswith(");") or (lines[i].strip().startswith(") u_") and lines[i].strip().endswith("(")):
                if lines[i - 1].strip().endswith(","):
                    lines[i - 1] = lines[i - 1].rstrip(",\n").rstrip() + "\n"
    with open("top.v", "w") as f:
        f.writelines(lines)

    # Sort wire declarations outside the module
    wire_lines = []
    non_wire_lines = []
    module_end = []
    for i, line in enumerate(lines):
        if line.strip().startswith("wire "):
            wire_lines.append(line)
        else:
            non_wire_lines.append(line)
        if line.strip() == ");":
            module_end.append(i)  # Capture the end of the module port list
    sorted_wire_lines = sorted(wire_lines, key=lambda x: x.strip().split()[1 if "[" not in x else 2])
    with open("top.v", "w") as f:
        for i, line in enumerate(non_wire_lines):
            f.write(line)
            if i == module_end[0]+1:
                f.writelines(sorted_wire_lines)

    print("top.v has been generated successfully!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate top.v")
    parser.add_argument("-check_width", action="store_true", help="Check signal widths for mismatches.")
    args = parser.parse_args()

    generate_top_v(check_width=args.check_width)
