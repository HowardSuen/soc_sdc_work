"""
# @ Author:      Zhenyu Yan(Kevin)
# @ Create Time: 2025-03-24
# @ Description: COPYRIGHT(C) 2022-2025. ALL RIGHTS RESERVED.
# @ Note:        Proprietary and Confidential Information. Not to be copied or distributed.
"""

import os
import argparse
import chardet
import re
from sympy import sympify


def detect_encoding(file_path):
    with open(file_path, "rb") as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        return result["encoding"]


def read_file_with_encoding(file_path):
    encoding = detect_encoding(file_path)
    print(f"File {file_path} encoding: {encoding}")
    with open(file_path, "r", encoding=encoding, errors="replace") as file:
        return file.readlines()


def load_defines(defines_file):
    defines = set()
    if defines_file:
        try:
            lines = read_file_with_encoding(defines_file)
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("`define "):
                    defines.add(line.split()[1])
        except Exception as e:
            print(f"Error loading defines file: {e}")
    return defines


def parse_parameters(lines):
    parameters = {}
    for line in lines:
        line = line.strip()
        if line.startswith("parameter"):
            parts = line.split("=")
            if len(parts) == 2:
                param_name = parts[0].split()[-1].strip()
                param_value = parts[1].split(";")[0].strip()
                parameters[param_name] = param_value
    return parameters


def replace_parameters(expression, parameters):
    for param, value in parameters.items():
        expression = expression.replace(param, value)
    return expression


def evaluate_expression(expression):
    try:
        start_expr, end_expr = expression.split(":")
        start_value = int(sympify(start_expr.strip()))
        end_value = int(sympify(end_expr.strip()))
        return f"{start_value}:{end_value}"
    except Exception as e:
        print(f"Error evaluating expression '{expression}': {e}")
        return expression


def generate_empty_v_file(input_file, defines_file=None):
    defines = load_defines(defines_file)
    base_name = os.path.splitext(os.path.basename(input_file))[0]
    output_file = f"{base_name}_empty.v"

    inside_block_comment = False
    output_signals = []

    try:
        lines = read_file_with_encoding(input_file)
        parameters = parse_parameters(lines)
        with open(output_file, "w", encoding="utf-8") as outfile:
            inside_module = False
            not_end_module = False
            keep_lines = True
            verilog_2001 = False
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("module"):
                    if f"module {base_name}" in line and line.split("(")[0].split()[1].replace(" ", "") == base_name:
                        inside_module = True
                        not_end_module = True
                        outfile.write(line + "\n")
                    else:
                        inside_module = False
                elif inside_module and line.startswith(");"):
                    outfile.write(line + "\n\n")
                    inside_module = False
                elif inside_module:
                    if inside_block_comment:
                        if "*/" in line:
                            inside_block_comment = False
                        continue
                    if line.startswith("//"):
                        continue
                    if "/*" in line and "*/" in line:
                        outfile.write("    " + line + "\n")
                        continue
                    if "/*" in line:
                        inside_block_comment = True
                        continue
                    if line.startswith("`ifdef"):
                        define = line.split()[1]
                        keep_lines = define in defines
                    elif line.startswith("`else"):
                        keep_lines = not keep_lines
                    elif line.startswith("`endif"):
                        keep_lines = True
                    elif keep_lines:
                        if line.startswith(("input ", "output ", "inout ")):
                            verilog_2001 = True
                            parts = line.split("[")
                            if len(parts) > 1:
                                width_expr = parts[1].split("]")[0]
                                resolved_width = replace_parameters(width_expr, parameters)
                                line = line.replace(width_expr, resolved_width)
                        outfile.write("    " + line + "\n")
                        if line.startswith("output "):
                            signal = line.split(",")[0].split()[-1]
                            output_signals.append(signal)
                elif not inside_module and not_end_module and not verilog_2001:
                    if inside_block_comment:
                        if "*/" in line:
                            inside_block_comment = False
                        continue
                    if line.startswith("//"):
                        continue
                    if "/*" in line and "*/" in line:
                        outfile.write("    " + line + "\n")
                        continue
                    if "/*" in line:
                        inside_block_comment = True
                        continue
                    if line.startswith("`ifdef"):
                        define = line.split()[1]
                        keep_lines = define in defines
                    elif line.startswith("`else"):
                        keep_lines = not keep_lines
                    elif line.startswith("`endif"):
                        keep_lines = True
                    elif keep_lines and not line.startswith("endmodule") and line.startswith(("input ", "output ", "inout ")):
                        parts = line.split("[")
                        if len(parts) > 1:
                            width_expr = parts[1].split("]")[0]
                            resolved_width = replace_parameters(width_expr, parameters)
                            line = line.replace(width_expr, resolved_width)
                        outfile.write(line + "\n")
                        if line.startswith("output "):
                            signal = line.split(";")[0].split()[-1]
                            output_signals.append(signal)
                if line.startswith("parameter") and not_end_module:
                    outfile.write(line + "\n")
                if "endmodule" in line and not_end_module:
                    outfile.write("\n")
                    for signal in output_signals:
                        outfile.write(f"assign {signal} = 'b0;\n")
                    outfile.write("\n" + line + "\n")
                    not_end_module = False

        with open(output_file, "r", encoding="utf-8") as infile:
            lines = infile.readlines()

        with open(output_file, "w", encoding="utf-8") as outfile:
            for line in lines:
                match = re.search(r"\[(.+?)\]", line)  # Find content inside square brackets
                if match:
                    expression = match.group(1)
                    evaluated_result = evaluate_expression(expression)
                    line = line.replace(f"[{expression}]", f"[{evaluated_result}]")
                outfile.write(line)

        print(f"Empty file generated: {output_file} (UTF-8 encoding)")
    except Exception as e:
        print(f"Error processing file: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate an empty .v file from the provided .v file.")
    parser.add_argument("-v", "--verilog", required=True, help="Path to the input .v file")
    parser.add_argument("-d", "--defines", help="Path to the defines file")
    args = parser.parse_args()

    generate_empty_v_file(args.verilog, args.defines)
