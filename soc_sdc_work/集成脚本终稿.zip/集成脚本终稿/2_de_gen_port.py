"""
# @ Author:      Zhenyu Yan(Kevin)
# @ Create Time: 2025-03-24
# @ Description: COPYRIGHT(C) 2022-2025. ALL RIGHTS RESERVED.
# @ Note:        Proprietary and Confidential Information. Not to be copied or distributed.
"""

import pandas as pd
import argparse
import os
import re


def create_owner_xlsx_files(xlsx_file):
    print(f"Creating owner-specific XLSX files from {xlsx_file}")
    df = pd.read_excel(xlsx_file)
    owners = df["owner"].unique()
    required_columns = ["Parameter", "Inout", "Inout Width", "Inout Connectivity", "Inout Name", "Input", "Input Width", "Input Used Width", "From Whom", "Output", "Output Width", "Output Used Width", "To Top"]

    for file_path in df["file_path"]:
        if not os.path.exists(file_path):
            print(f"File {file_path} does not exist.")

    for owner in owners:
        owner_df = df[df["owner"] == owner]
        owner_xlsx = f"port_{owner}.xlsx"
        # existing_data = {}
        # if os.path.exists(owner_xlsx):
        #     print(f"{owner_xlsx} already exists. It will be updated.")
        #     existing_data = pd.read_excel(owner_xlsx, sheet_name=None)
        # else:
        #     print(f"{owner_xlsx} does not exist. It will be created.")
        print(f"{owner_xlsx} will be created.")

        with pd.ExcelWriter(owner_xlsx, engine="xlsxwriter") as writer:
            for inst_name in owner_df["inst_name"].unique():
                inst_df = pd.DataFrame(columns=required_columns)
                for file_path in owner_df[owner_df["inst_name"] == inst_name]["file_path"]:
                    with open(file_path, "r", encoding="utf-8") as file:
                        line_num_p = 0
                        line_num_io = 0
                        line_num_i = 0
                        line_num_o = 0
                        for line in file:
                            if line.strip().startswith("parameter"):
                                inst_df.at[line_num_p, "Parameter"] = line.strip()
                                line_num_p += 1
                    with open(file_path, "r", encoding="utf-8") as file:
                        for line in file:
                            match = None
                            # Match Verilog 1995 and 2001 inout
                            if re.match(r"\s*\binout\b.*[;,]", line):
                                match = re.search(r"\binout\s+(?:wire\s+)?(\[\s*\d+\s*:\s*\d+\s*\])?\s*(\w+)", line)
                            elif re.match(r"\s*\binout\b.*[^,]\s*$", line):
                                match = re.search(r"\binout\s+(?:wire\s+)?(\[\s*\d+\s*:\s*\d+\s*\])?\s*(\w+)", line)
                            if match:
                                bit_width = match.group(1) if match.group(1) else "1"
                                signal_name = match.group(2)
                                inst_df.at[line_num_io, "Inout"] = signal_name
                                inst_df.at[line_num_io, "Inout Width"] = str(int(bit_width.split(":")[0][1:]) - int(bit_width.split(":")[1][:-1]) + 1) if bit_width != "1" else "1"
                                line_num_io += 1
                    with open(file_path, "r", encoding="utf-8") as file:
                        # Collect all parameter definitions in the file
                        param_dict = {}
                        param_pattern = re.compile(r"parameter\s+(\w+)\s*=\s*([0-9]+)")
                        for line in file:
                            param_match = param_pattern.match(line.strip())
                            if param_match:
                                param_name = param_match.group(1)
                                param_value = param_match.group(2)
                                param_dict[param_name] = param_value

                    with open(file_path, "r", encoding="utf-8") as file:
                        for line in file:
                            match = None
                            # Match Verilog 1995 and 2001 input, including parameterized width
                            if re.match(r"\s*\binput\b.*[;,]", line):
                                match = re.search(r"\binput\s+(?:wire\s+)?(\[[^\]]+\])?\s*(\w+)", line)
                            elif re.match(r"\s*\binput\b.*[^,]\s*$", line):
                                match = re.search(r"\binput\s+(?:wire\s+)?(\[[^\]]+\])?\s*(\w+)", line)
                            if match:
                                bit_width = match.group(1) if match.group(1) else "1"
                                signal_name = match.group(2)
                                width_str = "1"
                                if bit_width != "1":
                                    # Try to substitute parameter names with their values
                                    width_expr = bit_width[1:-1]  # remove [ and ]
                                    # Replace parameter names with their values
                                    for pname, pval in param_dict.items():
                                        width_expr = re.sub(rf"\b{pname}\b", pval, width_expr)
                                    try:
                                        # Now width_expr should be something like "8-1:0" or "7:0"
                                        if ":" in width_expr:
                                            msb, lsb = width_expr.split(":")
                                            msb_val = eval(msb.replace(" ", ""))
                                            lsb_val = eval(lsb.replace(" ", ""))
                                            width_val = abs(msb_val - lsb_val) + 1
                                            width_str = str(width_val)
                                        else:
                                            width_val = eval(width_expr.replace(" ", ""))
                                            width_str = str(width_val)
                                    except Exception:
                                        width_str = width_expr  # fallback to raw expr if eval fails
                                inst_df.at[line_num_i, "Input"] = signal_name
                                inst_df.at[line_num_i, "Input Width"] = width_str
                                line_num_i += 1
                    with open(file_path, "r", encoding="utf-8") as file:
                        for line in file:
                            match = None
                            # Match Verilog 1995 and 2001 output, including parameterized width
                            if re.match(r"\s*\boutput\b.*[;,]", line):
                                match = re.search(r"\boutput\s+(?:wire\s+)?(\[[^\]]+\])?\s*(\w+)", line)
                            elif re.match(r"\s*\boutput\b.*[^,]\s*$", line):
                                match = re.search(r"\boutput\s+(?:wire\s+)?(\[[^\]]+\])?\s*(\w+)", line)
                            if match:
                                bit_width = match.group(1) if match.group(1) else "1"
                                signal_name = match.group(2)
                                width_str = "1"
                                if bit_width != "1":
                                    # Try to substitute parameter names with their values
                                    width_expr = bit_width[1:-1]  # remove [ and ]
                                    # Replace parameter names with their values
                                    for pname, pval in param_dict.items():
                                        width_expr = re.sub(rf"\b{pname}\b", pval, width_expr)
                                    try:
                                        # Now width_expr should be something like "8-1:0" or "7:0"
                                        if ":" in width_expr:
                                            msb, lsb = width_expr.split(":")
                                            msb_val = eval(msb.replace(" ", ""))
                                            lsb_val = eval(lsb.replace(" ", ""))
                                            width_val = abs(msb_val - lsb_val) + 1
                                            width_str = str(width_val)
                                        else:
                                            width_val = eval(width_expr.replace(" ", ""))
                                            width_str = str(width_val)
                                    except Exception:
                                        width_str = width_expr  # fallback to raw expr if eval fails
                                inst_df.at[line_num_o, "Output"] = signal_name
                                inst_df.at[line_num_o, "Output Width"] = width_str
                                line_num_o += 1
                inst_df = inst_df.fillna("")  # Convert NaN to empty strings

                # if inst_name in existing_data:
                #     existing_df = existing_data[inst_name]
                #     for column in required_columns:
                #         if column in existing_df.columns:
                #             for idx, value in existing_df[column].items():
                #                 if value in inst_df[column].values:
                #                     inst_df.loc[inst_df[column] == value, column] = value  # Keep existing value

                inst_df.to_excel(writer, sheet_name=inst_name, index=False)
                worksheet = writer.sheets[inst_name]
                for column in inst_df:
                    column_width = max(inst_df[column].astype(str).map(len).max(), len(column)) + 2
                    col_idx = inst_df.columns.get_loc(column)
                    worksheet.set_column(col_idx, col_idx, column_width)
                    for row in range(len(inst_df)):
                        cell_value = inst_df.iloc[row, col_idx]
                        if cell_value:  # Only apply format to non-empty cells
                            numeric_value = pd.to_numeric(cell_value, errors="coerce")
                            if not pd.isna(numeric_value):
                                cell_value = numeric_value
                            if isinstance(cell_value, (int, float)):
                                # format = writer.book.add_format({"bg_color": "white" if inst_name in existing_data and column in existing_df.columns and cell_value in existing_df[column].values else "yellow", "align": "right", "border": 1})
                                # worksheet.write_number(row + 1, col_idx, cell_value, format)
                                worksheet.write_number(row + 1, col_idx, cell_value)
                            else:
                                # format = writer.book.add_format({"bg_color": "white" if inst_name in existing_data and column in existing_df.columns and cell_value in existing_df[column].values else "yellow", "border": 1})
                                # worksheet.write(row + 1, col_idx, cell_value, format)
                                worksheet.write(row + 1, col_idx, cell_value)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="create owner-specific XLSX files")
    parser.add_argument("-x", "--xlsx", help="Path to the input XLSX file")
    parser.add_argument("-gen_port", help="Generate port files according to owners", action="store_true")
    args = parser.parse_args()

    if args.gen_port:
        create_owner_xlsx_files(args.xlsx if args.xlsx else "info_all.xlsx")
